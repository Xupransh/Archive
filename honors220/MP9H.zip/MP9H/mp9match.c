#include <stdint.h>
#include <stdio.h>

#include "mp5.h"
#include "mp9.h"


int32_t
match_requests (graph_t* g, pyr_tree_t* p, heap_t* h,
		request_t* r1, request_t* r2,
		vertex_set_t* src_vs, vertex_set_t* dst_vs, path_t* path)
{
		src_vs->count = 0;
		dst_vs->count = 0;
		locale_t *r1_from = &(r1->from);
		locale_t *r1_to = &(r1->to);
		locale_t *r2_from = &(r2->from);
		locale_t *r2_to = &(r2->to);

		//build source vertex set
		if(r1_from->range < r2_from ->range)
		{
				find_nodes(r1_from, src_vs, p, 0);
				trim_nodes(g,src_vs,r2_from);
		}
		else
		{
				find_nodes(r2_from, src_vs, p, 0);
				trim_nodes(g,src_vs,r1_from);
		}
		//build dest vertex set
		if(r1_to->range < r2_to ->range)
		{
				find_nodes(r1_to, dst_vs, p, 0);
				trim_nodes(g,dst_vs,r2_to);
		}
		else
		{
				find_nodes(r2_to, dst_vs, p, 0);
				trim_nodes(g,dst_vs,r1_to);
		}

		return dijkstra(g,h,src_vs,dst_vs,path);

}
