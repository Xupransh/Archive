#!/bin/bash

if [ -f ./code.asm ]; then
    rm code.asm
fi

cat test.c | ./c220-gold >> code.asm
lc3as code.asm
lc3sim code.obj
