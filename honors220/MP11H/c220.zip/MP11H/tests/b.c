int 
main ()
{
    int i;

    for (i = -10; 10 >= i; i++) {
        printf ("%d %d\n", i, i % 10);
    }

    return 2;
}


