int main () {
    int i;
    int j;
    i = &j;
    printf ("%d\n", "Hello!\n");
    printf ("i at %d, j at %d\n", &i, &j);
    scanf ("%d", i);
    printf ("\n\nj is now %d\n", j);
    return 19;
}
