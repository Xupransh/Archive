int main()
{
    int a;
    a = 10;
    a = -a;
    printf("%d\n", a);
    return 1;
}
